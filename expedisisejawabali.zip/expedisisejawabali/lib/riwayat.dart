import 'package:flutter/material.dart';

class RiwayatPage extends StatelessWidget {
  const RiwayatPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> riwayatList = [
      {
        "muatan": "Elektronik - Surabaya → Bali",
        "harga": "Rp 2.500.000",
        "tanggal": "10 Okt 2025",
        "rating": 4.8,
        "status": "Selesai",
      },
      {
        "muatan": "Bahan Bangunan - Malang → Solo",
        "harga": "Rp 1.800.000",
        "tanggal": "28 Sep 2025",
        "rating": 4.6,
        "status": "Selesai",
      },
      {
        "muatan": "Furniture - Jakarta → Banyuwangi",
        "harga": "Rp 3.200.000",
        "tanggal": "15 Sep 2025",
        "rating": 4.9,
        "status": "Selesai",
      },
    ];

    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.blueAccent,
        elevation: 0,
        title: const Text(
          "Riwayat Muatan",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: riwayatList.length,
        itemBuilder: (context, index) {
          final data = riwayatList[index];
          return _buildRiwayatCard(data);
        },
      ),
    );
  }

  Widget _buildRiwayatCard(Map<String, dynamic> data) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.5),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Judul & harga
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    data["muatan"],
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                    ),
                  ),
                ),
                Text(
                  data["harga"],
                  style: const TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),

            
            Row(
              children: [
                const Icon(Icons.calendar_today, size: 16, color: Colors.grey),
                const SizedBox(width: 6),
                Text(
                  data["tanggal"],
                  style: const TextStyle(color: Colors.grey, fontSize: 13),
                ),
                const Spacer(),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.green.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Text(
                    data["status"],
                    style: const TextStyle(
                      color: Colors.green,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),

            // Rating pelanggan
            Row(
              children: [
                ...List.generate(
                  5,
                  (i) => Icon(
                    i < data["rating"].floor()
                        ? Icons.star
                        : (i < data["rating"]
                            ? Icons.star_half
                            : Icons.star_border),
                    color: Colors.amber,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  "${data["rating"]}",
                  style: const TextStyle(
                    color: Colors.black54,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
