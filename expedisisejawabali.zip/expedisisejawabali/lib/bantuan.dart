import 'package:flutter/material.dart';

class BantuanPage extends StatelessWidget {
  const BantuanPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> bantuanList = [
      {
        "judul": "Cara mengambil muatan",
        "isi":
            "1. Masuk ke menu Muatan.\n2. Pilih muatan yang tersedia.\n3. Tekan tombol 'Pasang ke Muatan'.\n4. Tunggu konfirmasi dari admin ekspedisi.",
      },
      {
        "judul": "Cara melihat riwayat pengiriman",
        "isi":
            "Masuk ke menu Riwayat untuk melihat daftar muatan yang telah kamu antar beserta rating pelanggan.",
      },
      {
        "judul": "Peraturan ekspedisi",
        "isi":
            "Sopir wajib menjaga keselamatan dan memastikan barang sampai tujuan dengan baik. Barang yang rusak karena kelalaian akan dikenakan sanksi sesuai peraturan perusahaan.",
      },
    ];

    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.blueAccent,
        elevation: 0,
        title: const Text(
          "Bantuan & Panduan",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Daftar panduan
          ...bantuanList.map((data) => _buildBantuanCard(data)).toList(),
          const SizedBox(height: 20),

          // Kontak Bantuan
          _buildKontakCard(),
        ],
      ),
    );
  }

  Widget _buildBantuanCard(Map<String, String> data) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha:0.5),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: ExpansionTile(
        title: Text(
          data["judul"]!,
          style: const TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 15,
            color: Colors.black87,
          ),
        ),
        childrenPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 10,
        ),
        children: [
          Text(
            data["isi"]!,
            style: const TextStyle(color: Colors.black54, fontSize: 13.5),
          ),
        ],
      ),
    );
  }

  Widget _buildKontakCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha:0.5),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Butuh Bantuan?",
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Colors.blueAccent,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "Hubungi tim support ekspedisi jika mengalami kendala dalam pengiriman.",
            style: TextStyle(color: Colors.black54, fontSize: 13.5),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Icon(Icons.phone_in_talk, color: Colors.blueAccent),
              const SizedBox(width: 10),
              const Text(
                "+62 812-3456-7890",
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              const Icon(Icons.email_rounded, color: Colors.blueAccent),
              const SizedBox(width: 10),
              const Text(
                "support@ekspedisijb.com",
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
