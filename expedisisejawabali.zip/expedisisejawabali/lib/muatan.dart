import 'package:flutter/material.dart';

class MuatanPage extends StatelessWidget {
  const MuatanPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> muatanList = [
      {
        "nama": "Beras • Surabaya → Bali",
        "harga": "Rp 2.500.000",
        "target": "2 Hari",
      },
      {
        "nama": "Apel • Malang → Solo",
        "harga": "Rp 1.800.000",
        "target": "1 Hari",
      },
      {
        "nama": "Cabe • Banyuwangi → Jakarta",
        "harga": "Rp 4.200.000",
        "target": "1 Hari",
      },
      {
        "nama": "Semangka • Demak → Jakarta",
        "harga": "Rp 2.900.000",
        "target": "2 Hari",
      },
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF6F6F6),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: const Color.fromARGB(241, 49, 163, 255),
        title: Row(
          children: [
            Image.asset("assets/Logo_truk.png", height: 50),
            const SizedBox(width: 10),
            const Text(
              "Muatan",
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            )
          ],
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(14),
        itemCount: muatanList.length,
        itemBuilder: (context, index) {
          final m = muatanList[index];
          return _gojekCard(
            nama: m['nama'],
            harga: m['harga'],
            target: m['target'],
            context: context,
          );
        },
      ),
    );
  }

  Widget _gojekCard({
    required String nama,
    required String harga,
    required String target,
    required BuildContext context,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.shade100),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 8,
            spreadRadius: 2,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.asset(
              'assets/maps.png',
              height: 85,
              width: 85,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  nama,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(
                      Icons.monetization_on,
                      size: 18,
                      color: Color.fromARGB(241, 49, 163, 255),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      harga,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(241, 49, 163, 255),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                Row(
                  children: [
                    const Icon(Icons.access_time, size: 16, color: Colors.grey),
                    const SizedBox(width: 5),
                    Text(
                      target,
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    )
                  ],
                ),
                const SizedBox(height: 10),
                Align(
                  alignment: Alignment.bottomRight,
                  child: ElevatedButton(
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                            content: Text('Muatan "$nama" berhasil dipasang!')),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(241, 49, 163, 255),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: const Text(
                      "Muat",
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
