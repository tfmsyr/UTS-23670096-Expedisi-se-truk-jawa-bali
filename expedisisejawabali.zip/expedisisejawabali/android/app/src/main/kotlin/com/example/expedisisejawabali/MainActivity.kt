package com.example.expedisisejawabali

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
